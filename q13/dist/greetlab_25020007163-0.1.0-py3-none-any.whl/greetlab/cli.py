import argparse
import sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    a = p.parse_args()
    if not a.name or a.name.isspace():
        print("Error: name cannot be blank", file=sys.stderr)
        sys.exit(2)
    print(f"Hello, {a.name}!")

if __name__ == "__main__":
    main()
